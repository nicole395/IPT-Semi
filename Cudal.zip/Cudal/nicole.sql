-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2020 at 05:42 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nicole`
--

-- --------------------------------------------------------

--
-- Table structure for table `cudal`
--

CREATE TABLE `cudal` (
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `about_me` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cudal`
--

INSERT INTO `cudal` (`fname`, `lname`, `gender`, `email`, `address`, `contact`, `about_me`) VALUES
('Nicole Odvina', 'Cudal', 'Male', 'cudalcolas@gmail.com', 'P-5 ongyiu butuan city', '09157084118', 'Hi I\'m Nicole Odvina Cudal, you can just call me \'colas\' I am currently residing at Purok 5 Brgy Ong Yiu, Butuan City. I graduated at Agusan National High School in my Junior High and continued my Senior Years at Saint Joseph Institute of Technology (Basic Education Department) with the track Accountanancy Business and Management (ABM) and currently enrolled at Father Saturnino Urios University taking up Bachelor of Science in Information Technology I am now at 3rd Year and Hopefully can pass so that  can graduate');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
