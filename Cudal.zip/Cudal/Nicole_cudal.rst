######## INSTALLATION FOR MY WEB APPLICATION ##############


STEP 1: YOU MUST IMPORT THE nicole.sql in localhost.
STEP 2: AFTER YOU UPLOADED THE FILE. THE DATABASE NAME IS "nicole" DATABASE TABLE IS "cudal".
STEP 3: NOW VISIT THIS LINK: http://localhost/Cudal/Nicole/main