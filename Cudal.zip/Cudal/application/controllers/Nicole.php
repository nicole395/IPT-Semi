<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Nicole extends CI_Controller
{
    /**
     * summary
     */
    function main(){

    	$data['tbl_d'] = $this->data->get_data_from_tbl();
    	$this->load->view('main/index',$data);
    }

    function __construct()
    {
    	parent:: __construct();
    	$this->load->model('data','data');
    }

    function personal(){
		$data['person'] = $this->data->get_data_from_tbl();
    	$this->load->view('main/personal',$data);
    }
    function about_me(){
		$data['about'] = $this->data->get_data_from_tbl();
    	$this->load->view('main/about',$data);
    }
}


?>