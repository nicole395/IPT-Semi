<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Data extends CI_Model
{
    /**
     * summary
     */
    public function get_data_from_tbl()
    {
        $table = $this->db->table_exists('cudal');
	    	if ($table) {
	    		$que = $this->db->get('cudal');
	    		if ($que->num_rows() > 0) {
	    			return $que->result();
	    		}
	    		else{
	    			return false;
	    		}
	    	}
	    	else {
	    		return false;
	    	}
    }
}

?>