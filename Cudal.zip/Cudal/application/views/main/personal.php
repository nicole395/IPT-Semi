<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
	<title><?php 

		if ($person) {
			foreach ($person as $data) {
			    echo $data->fname." ".$data->lname;
			}
		}

	?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
</head>
<body>

	<main>
		<div class="color">
			<!-- flex -->
			<div class="head">
				<a href="<?php echo base_url('Nicole/main'); ?>" title="Bert"><span>My Web application</span></a>
				<div class="list">
					<ul>
						<li><a id="person" href="<?php echo base_url('Nicole/personal'); ?>">Personal</a></li>
						<li><a href="<?php echo base_url('Nicole/about_me'); ?>">About</a></li>
						<!-- <li><span>Personal</span></li> -->
					</ul>
				</div>
			</div>

			<div class="tomato">
				<div class="header">
					<center><h3>Personal Information</h3></center>
				</div>
				<div class="flex">
					<div class="text">
					<ul>
						<li><span>Name: <?php 
						if ($person) {
							foreach ($person as $data) {
								echo $data->fname." ".$data->lname;
								}
							}
						?></span></li>
						<li><span>Enail: <?php 
						if ($person) {
							foreach ($person as $data) {
								echo $data->email;
								}
							}
						?></span></li>
						<li><span>Gender: <?php 
						if ($person) {
							foreach ($person as $data) {
								echo $data->gender;
								}
							}
						?></span></li>
						<li><span>Address: <?php 
						if ($person) {
							foreach ($person as $data) {
								echo $data->address;
								}
							}
						?></span></li>
						<li><span>Contact #: <?php 
						if ($person) {
							foreach ($person as $data) {
								echo $data->contact;
								}
							}
						?></span></li>
					</ul>
				</div>
				</div>
			</div>
	</main>


	<script type="text/javascript">
		
		function about(){
			window.location.href="<?php echo base_url('Nicole/about_me'); ?>";
		}

	</script>
	
</body>
</html>

