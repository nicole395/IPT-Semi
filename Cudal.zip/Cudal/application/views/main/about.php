<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
	<title><?php 

		if ($about) {
			foreach ($about as $data) {
			    echo $data->fname." ".$data->lname;
			}
		}

	?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
</head>
<body>

	<main>
		<div class="color">
			<!-- flex -->
			<div class="head">
				<a href="#" title="Bert"><span>My Web application</span></a>
				<div class="list">
					<ul>
						<li><a id="person" href="<?php echo base_url('Nicole/personal'); ?>">Personal</a></li>
						<!-- <li><a>About</a></li> -->
						<!-- <li><span>Personal</span></li> -->
					</ul>
				</div>
			</div>

			<div class="tomato">
				<div class="header">
					<center><h3>About Me</h3></center>
				</div>
				<div class="flex">
					<div class="about">
					<p><?php 

					if ($about) {
						foreach ($about as $data) {
						    echo $data->about_me;
						}
					}

				?></p>
					<br>
					<center><button onclick="back();">Back</button></center>
				</div>
				</div>
			</div>
	</main>

	<script type="text/javascript">
		
		function back(){
			window.location.href="<?php echo base_url('Nicole/main'); ?>";
		}

	</script>
	
</body>
</html>